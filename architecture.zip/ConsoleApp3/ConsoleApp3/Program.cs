﻿using System;
using System.Net.Http;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        string host = "192.168.93.246";
        string apiUrlTryGuess = $"http://{host}:5126/api/game/tryGuess?";
        string apiUrlgetWinner = $"http://{host}:5127/api/game/getWinner";

        Console.WriteLine("game/game-rmod/winner");
        string mode = Console.ReadLine();
        if (mode == "game")
        {
            Console.WriteLine("Player name:");
            string player = Console.ReadLine();

            int i = 0;
            int sleepmod = 200;
            for(; ; )
            {
                i++;
                int sleep = sleepmod * i;
                string urlWithParams = $"{apiUrlTryGuess}player={player}&number={i}";
                using (var client = new HttpClient())
                {
                    try
                    {
                        var request = new HttpRequestMessage
                        {
                            Method = HttpMethod.Get,
                            RequestUri = new Uri(urlWithParams)
                        };
                        var response = await client.SendAsync(request).ConfigureAwait(false);
                        var responseInfo = await response.Content.ReadAsStringAsync();

                        Console.WriteLine(responseInfo);
                        Console.WriteLine(":) yees");
                        Thread.Sleep(sleep);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.StackTrace);
                    }
                }

                if (i == 5)
                {
                    i = 0;
                    Console.WriteLine(":( nooo");
                    Thread.Sleep(sleep);
                }
            }         
        }
        else if(mode == "game-rmod")
        {
            Console.WriteLine("Player name:");
            string player = Console.ReadLine();

            int i = 0;
            int sleepmod = 200;
            string controlNumber = null;
            for (; ; )
            {
                i++;
                int sleep = sleepmod * i;
                string apiUrlTryGuessLoadBalancer = apiUrlTryGuess.Replace("5126", "8080");
                string urlWithParams = $"{apiUrlTryGuessLoadBalancer}player={player}&number={i}";
                
                using (var client = new HttpClient())
                {
                    try
                    {
                        var request = new HttpRequestMessage
                        {
                            Method = HttpMethod.Get,
                            RequestUri = new Uri(urlWithParams)
                        };
                        var response = await client.SendAsync(request).ConfigureAwait(false);
                        var responseInfo = await response.Content.ReadAsStringAsync();

                        if (!responseInfo.Contains("WIN"))
                        {
                            string winNo = responseInfo.Split(';')[0];
                            if (controlNumber != null && winNo != controlNumber)
                                Console.WriteLine("Win nomber is CORUPTED!!!");
                            else
                            {
                                Console.WriteLine(responseInfo);
                                controlNumber = winNo;
                            }
                        }
                        else 
                        {
                            controlNumber = null;
                            Console.WriteLine(responseInfo);
                            Console.WriteLine(":) yees");
                            Thread.Sleep(sleep);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.StackTrace);
                    }
                }

                if (i == 5)
                {
                    i = 0;
                    controlNumber = null;
                    Console.WriteLine(":( nooo");
                    Thread.Sleep(sleep);
                }
            }
        }
        else if (mode == "winner")
        {
            for (; ; )
            {
                using (var client = new HttpClient())
                {
                    try
                    {
                        var request = new HttpRequestMessage
                        {
                            Method = HttpMethod.Get,
                            RequestUri = new Uri(apiUrlgetWinner)
                        };
                        var response = await client.SendAsync(request).ConfigureAwait(false);

                        var responseInfo = await response.Content.ReadAsStringAsync();
                        Thread.Sleep(2000);
                        Console.WriteLine(DateTime.Now + responseInfo);

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.StackTrace);
                    }
                }
            }
            Console.ReadLine();
        }
    }
}


