﻿using System;
using System.Net.Http;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        string host = "192.168.1.101";
        string apiUrlTryGuess = $"http://{host}:5126/api/game/tryGuess?";
        string apiUrlgetWinner = $"http://{host}:5127/api/game/getWinner";

        Console.WriteLine("game/winner");
        string mode = Console.ReadLine();
        if (mode == "game")
        {
            Console.WriteLine("Play Now!");

            while (true)
            {
                string[] play = Console.ReadLine().Split(';');
                string urlWithParams = $"{apiUrlTryGuess}player={play[0]}&number={play[1]}";
                using (var client = new HttpClient())
                {
                    try
                    {
                        var request = new HttpRequestMessage
                        {
                            Method = HttpMethod.Get,
                            RequestUri = new Uri(urlWithParams)
                        };
                        var response = await client.SendAsync(request).ConfigureAwait(false);
                        var responseInfo = await response.Content.ReadAsStringAsync();

                        Console.WriteLine(responseInfo);

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.StackTrace);
                    }
                }
            }
        }
        else if (mode == "winner")
        {
            for (; ; )
            {
                using (var client = new HttpClient())
                {
                    try
                    {
                        var request = new HttpRequestMessage
                        {
                            Method = HttpMethod.Get,
                            RequestUri = new Uri(apiUrlgetWinner)
                        };
                        var response = await client.SendAsync(request).ConfigureAwait(false);

                        var responseInfo = await response.Content.ReadAsStringAsync();
                        Thread.Sleep(2000);
                        Console.WriteLine(responseInfo);

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.StackTrace);
                    }
                }
            }
            Console.ReadLine();
        }
    }
}


