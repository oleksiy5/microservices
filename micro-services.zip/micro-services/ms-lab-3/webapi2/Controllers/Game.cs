using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;


namespace webapi.Controllers;

[ApiController]
[Route("api/game")]
public class GameController : ControllerBase
{
   private const string _webApi3 = "http://olek:5128/api/game/readFile";

   public GameController()
   {
   }
   
   [HttpGet("getWinner")]
   public string GetWinner()
   {
	string urlWithParams = $"{_webApi3}";
	using (var client = new HttpClient())
	{	    	    
           try
	   {   
	      var request = new HttpRequestMessage
		{
		    Method = HttpMethod.Get,
		    RequestUri = new Uri(urlWithParams)
		};

		var response =  client.Send(request);
		using var reader = new StreamReader(response.Content.ReadAsStream());          
		return $"last winner: ({reader.ReadToEnd()})";

	    }
	    catch (Exception ex)
	    {
		return ex.Message + ex.StackTrace;
	    }
	}
   }
}


