using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;


namespace webapi.Controllers;

[ApiController]
[Route("api/game")]
public class GameController : ControllerBase
{
   private static int _winNumber;
   private static Random _rn = new Random();

   public GameController()
   {
   	if(_winNumber == 0)
   	{		
   	   	_winNumber = _rn.Next(1,5);
   	}	
   }
   
   [HttpGet("tryGuess")]
   public string TryGuess(string player, int number)
   {
        if(number == _winNumber)
        {
        	_winNumber = 0;
        	return "you win";
        }
        else
	   	return "try again";
   }
}


