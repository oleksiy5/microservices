using System;
using System.Net.Http;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        string apiUrl = "http://localhost:5126/api/game/tryGuess?";
        Console.WriteLine("Play Now!");
        
        while(true)
        {
                string[] play = Console.ReadLine().Split(';');        
		string urlWithParams = $"{apiUrl}player={play[0]}&number={play[1]}";
		using (var client = new HttpClient())
		{	    	    
	           try
		   {   
		      var request = new HttpRequestMessage
			{
			    Method = HttpMethod.Get,
			    RequestUri = new Uri(urlWithParams)
			};
			var response = await client.SendAsync(request).ConfigureAwait(false);
			var responseInfo = await response.Content.ReadAsStringAsync();

			Console.WriteLine(responseInfo);

		    }
		    catch (Exception ex)
		    {
			Console.WriteLine(ex.StackTrace);
		    }
		}		
	}	
    }        
}


