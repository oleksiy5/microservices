using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;


namespace webapi.Controllers;

[ApiController]
[Route("api/game")]
public class GameController : ControllerBase
{
   private static int _winNumber;
   private static Random _rn = new Random();
   private const string _winnerFile = "winner.txt";

   public GameController()
   {
   	if(_winNumber == 0) 			
   	   	_winNumber = _rn.Next(1,5);
   }
   
   [HttpGet("tryGuess")]
   public string TryGuess(string player, int number)
   {
        if(number == _winNumber)
        {
        	_winNumber = 0;
        	//WriteFile API//System.IO.File.WriteAllText(_winnerFile, player);
        	return "you win";
        }
        else
	   	return "try again";
   }
   
   [HttpGet("getWinner")]
   public string GetWinner()
   {
        if(System.IO.File.Exists(_winnerFile))
        	//ReadFileApi//return System.IO.File.ReadAllText(_winnerFile);
        else
	   	return "no winner";
   }
}


