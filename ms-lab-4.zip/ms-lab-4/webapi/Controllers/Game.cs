using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;


namespace webapi.Controllers;

[ApiController]
[Route("api/game")]
public class GameController : ControllerBase
{
   private static int _winNumber;
   private static Random _rn = new Random();
   private const string _webApi3 = "http://olek:5128/api/game/writeFile?player=";

   public GameController()
   {
   	if(_winNumber == 0) 			
   	   	_winNumber = _rn.Next(1,5);
   }
   
   [HttpGet("tryGuess")]
   public string TryGuess(string player, int number)
   {	
        if(number == _winNumber)
        {
        	string urlWithParams = $"{_webApi3}{player}";
		using (var client = new HttpClient())
		{	    	    
	           try
		   {   
		      var request = new HttpRequestMessage
			{
			    Method = HttpMethod.Get,
			    RequestUri = new Uri(urlWithParams)
			};

			var response =  client.Send(request);
			using var reader = new StreamReader(response.Content.ReadAsStream());          
			string r = $"{_winNumber};WIN ({reader.ReadToEnd()})"; 
			_winNumber = _rn.Next(1,5);
			return r;

		    }
		    catch (Exception ex)
		    {
			return ex.Message + ex.StackTrace;
		    }
		    //NOTE: I add win number to response to catch corupted behaviour.
		}	
        		
        	return $"{_winNumber};WIN";
        }
        else
	   	return $"{_winNumber};NO";
   }
}


