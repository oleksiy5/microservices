using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;


namespace webapi.Controllers;

[ApiController]
[Route("api/game")]
public class GameController : ControllerBase
{
   private const string _winnerFile = "winner.txt";

   public GameController()
   {
   }
   
   [HttpGet("writeFile")]
   public string WriteFile(string player)
   {
       	System.IO.File.WriteAllText(_winnerFile, player);
        return "OK...";
   }
   
   [HttpGet("readFile")]
   public string ReadFile()
   {
        return System.IO.File.ReadAllText(_winnerFile);
   }
}


