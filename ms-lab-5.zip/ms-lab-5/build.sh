dotnet publish -c Release -o out
docker build -t webapi2 .
