export ip=192.168.1.101
docker stop $(docker ps -qa)
docker rm $(docker ps -qa)
docker run -d -p 5126:80 --add-host=olek:$ip webapi1_v2
docker run -d -p 5127:80 --add-host=olek:$ip webapi2
docker run -d -p 5128:80 --add-host=olek:$ip webapi3
docker run -d -p 51266:80 --add-host=olek:$ip webapi1
docker run -d -p 8080:8080 --add-host=olek:$ip nginx

