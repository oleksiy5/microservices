using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;


namespace webapi.Controllers;

[ApiController]
[Route("api/game")]
public class GameController : ControllerBase
{
   private const string _winnerFile = "winner.txt";
   private const string _numberFile = "number.txt";

   public GameController()
   {
   }
   
   [HttpGet("writeFile")]
   public string WriteFile(string player)
   {
       	System.IO.File.WriteAllText(_winnerFile, player);
        return "OK...";
   }
   
   [HttpGet("readFile")]
   public string ReadFile()
   {
        return System.IO.File.ReadAllText(_winnerFile);
   }
   
   [HttpGet("writeNumber")]
   public string WriteNumber(string number)
   {
       	System.IO.File.WriteAllText(_numberFile, number);
        return "OK...";
   }
   
   [HttpGet("readNumber")]
   public string ReadNumber()
   {
        return System.IO.File.ReadAllText(_numberFile);
   }
}


