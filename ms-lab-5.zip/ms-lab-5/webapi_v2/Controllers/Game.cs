using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;


namespace webapi.Controllers;

[ApiController]
[Route("api/game")]
public class GameController : ControllerBase
{
   private static int _winNumber;
   private static Random _rn = new Random();
   private const string _webApi3 = "http://olek:5128/api/game/writeFile?player=";
   private const string _webApi3_v2 = "http://olek:5128/api/game/";


   public GameController()
   {
   	SpecWinnNumebr(false);
   }
   
   void SpecWinnNumebr(bool isWon)
   {
   	   string s = SendData("readNumber","");
   	   int no = int.TryParse(s, out no) ? no : 0;	
   	   	
   	   if(no == 0)
   	   {
   	      	  _winNumber = _rn.Next(1,5);
   	      	  SendData("writeNumber", $"number={_winNumber.ToString()}");//mozna wpisac nr
   	   }
   	   else
   	   {
   	      	  _winNumber = no;
   	      	  if(isWon)
   	      	  	SendData("writeNumber", "number=0");//zwyciezca robi reset
   	   }
   }
   
   void SpecWinnerName(string player)
   {
   	SendData("writeFile", $"player={player}");
   }
   
   string SendData(string method, string param)
   {
   	string r = "";
   	
   	string urlWithParams = $"{_webApi3_v2}{method}?{param}";
	using (var client = new HttpClient())
	{	    	    
           try
	   {   
	      var request = new HttpRequestMessage
		{
		    Method = HttpMethod.Get,
		    RequestUri = new Uri(urlWithParams)
		};

		var response =  client.Send(request);
		using var reader = new StreamReader(response.Content.ReadAsStream());          
		r = reader.ReadToEnd(); 

	    }
	    catch (Exception ex)
	    {
		return ex.Message + ex.StackTrace;
	    }
	}	

   	return r;
   }
      
   [HttpGet("tryGuess")]
   public string TryGuess(string player, int number)
   {	
        if(number == _winNumber)
        {
                SpecWinnNumebr(true);  
                SpecWinnerName(player);      		
        	return $"{_winNumber};{number};WIN";
        }
        else
        {
           SpecWinnNumebr(false);  
	   return $"{_winNumber};NO";
	}
   }
}


